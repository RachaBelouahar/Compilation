x = 12;
Si (x * 2 > 12 + 3) {
    y = 30;
    TantQue (y > x - 3) y = y-x ;
} Sinon y = x;
